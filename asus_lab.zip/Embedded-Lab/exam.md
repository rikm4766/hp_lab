# 8081 Micro Controller
### 01. Write an 8051 C program in Keil and design a circuit in Proteus to automatically blink an LED connected to P2.0 at 500 ms intervals.
``` c
#include <reg51.h>

sbit LED = P2^0;

void delay_1ms() {
  TH0 = 0xFC;
  TL0 = 0x18;
  TF0 = 0;
  TR0 = 1;
  while(TF0 == 0);
  TR0 = 0;
  TF0 = 0;
}

void delay_ms(unsigned int ms) {
  unsigned int i;
  for(i = 0; i < ms; i++)
    delay_1ms();
}

void main() {
  TMOD = 0x01;
  LED = 1;

  while(1) {
    LED = 0;
    delay_ms(500);

    LED = 1;
    delay_ms(500);
  }
}
```
``` bash
> Alt + F7
> Xtal = 12.0 MHz
> Output -> Create HEX File
> F7
```
### Diagram: [BlinkLED](Proteus/BlinkLED.pdsprj)
![Blink LED](Diagrams/BlinkLED.png)
---
### 02. Write an 8051 C program in Keil and design a circuit in Proteus to read an active-LOW push-button input on P1.0 and control an LED connected to P2.0 accordingly.
``` c
#include <reg51.h>

sbit SW = P1^0;
sbit LED = P2^0;

void main() {
  SW = 1;
  LED = 0;

  while(1) {
    if(SW == 0)
      LED = 1;
    else
      LED = 0;
  }
}
```
``` bash
> Alt + F7
> Xtal = 12.0 MHz
> Output -> Create HEX File
> F7
```
### Diagram: [ButtonBlink](Proteus/ButtonBlink.pdsprj)
![Blink LED](Diagrams/ButtonBlink.png)
---
### 03. Interface three LEDs representing Red, Yellow, and Green traffic lights with an 8051 microcontroller (AT89C51). Write an embedded C program in Keil μVision to control the LEDs in a continuous traffic-light sequence with suitable time delays. Compile the program and generate the HEX file. Then design the corresponding circuit in Proteus, load the generated HEX file into the AT89C51, and simulate the circuit to verify the correct operation of the traffic-light sequence.
``` c
#include <reg51.h>

sbit RED = P2^0;
sbit YELLOW = P2^1;
sbit GREEN = P2^2;

void delay_50ms() {
  TH0 = 0x3C;
  TL0 = 0xB0;
  TF0 = 0;
  TR0 = 1;
  while(TF0 == 0);
  TR0 = 0;
  TF0 = 0;
}

void delay_units(unsigned int n) {
  unsigned int i;
  for(i = 0; i < n; i++)
    delay_50ms();
}

void main() {
  TMOD = 0x01;

  RED = 1;
  YELLOW = 0;
  GREEN = 0;

  while(1) {
    RED = 1;
    YELLOW = 0;
    GREEN = 0;
    delay_units(100);

    RED = 0;
    YELLOW = 1;
    GREEN = 0;
    delay_units(80);

    RED = 0;
    YELLOW = 0;
    GREEN = 1;
    delay_units(50);
  }
}
```
``` bash
> Alt + F7
> Xtal = 12.0 MHz
> Output -> Create HEX File
> F7
```
### Diagram: [TrafficLight](Proteus/TrafficLight.pdsprj)
![Blink LED](Diagrams/TrafficLight.png)
---
### 04. Interface an LED display with an 8051 microcontroller (AT89C51) and write an embedded C program in Keil μVision to display any desired message, such as “WELCOME” or “HELLO”. Compile the program and generate the HEX file. Design the corresponding circuit in Proteus, load the generated HEX file into the microcontroller, and simulate the circuit to verify the correct display of the message.
``` c
#include <reg51.h>

sbit RS = P3^0;
sbit EN = P3^1;

void delay_ms(unsigned int ms) {
  unsigned int i;
  for(i = 0; i < ms; i++) {
    TH0 = 0xFC;
    TL0 = 0x66;
    TF0 = 0;
    TR0 = 1;
    while(TF0 == 0);
    TR0 = 0;
  }
}

void lcd_pulse() {
  EN = 1;
  delay_ms(1);
  EN = 0;
  delay_ms(1);
}

void lcd_cmd(unsigned char cmd) {
  RS = 0;
  P2 = cmd;
  lcd_pulse();
  delay_ms(2);
}

void lcd_data(unsigned char dat) {
  RS = 1;
  P2 = dat;
  lcd_pulse();
  delay_ms(1);
}

void lcd_string(char *str) {
  while(*str)
    lcd_data(*str++);
}

void lcd_init() {
  lcd_cmd(0x38);
  lcd_cmd(0x0C);
  lcd_cmd(0x06);
  lcd_cmd(0x01);
  lcd_cmd(0x80);
}

void main() {
  TMOD = 0x01;
  P2 = 0x00;
  RS = 0;
  EN = 0;

  delay_ms(20);
  lcd_init();

  lcd_string("WELCOME!!");
  lcd_cmd(0xC0);
  lcd_string("CHITTA");

  while(1);
}
```
``` bash
> Alt + F7
> Xtal = 12.0 MHz
> Output -> Create HEX File
> F7
```
### Diagram: [LEDDisplay](Proteus/LEDDisplay.pdsprj)
![Blink LED](Diagrams/LEDDisplay.png)
---
# 8085 Micro Processor
### 01. Write an 8085 assembly language program to multiply two 8-bit numbers stored in memory locations 2050H and 2051H using the successive addition method. Store the resulting 16-bit product across consecutive memory locations 2052H (Lower Byte) and 2053H (Higher Byte).
``` asm
LDA 2050H
MOV E, A
MVI D, 00H
LDA 2051H
MOV C, A
LXI H, 0000H
MOV A, C
ORA A
JZ STORE
LOOP: DAD D
DCR C
JNZ LOOP
STORE: SHLD 2052H
HLT
```
---
### 02. Write an 8085 assembly language program to perform division of an 8-bit dividend (at 2050H) by an 8-bit divisor (at 2051H) using repeated subtraction. Store the Quotient in memory location 2052H and Remainder in memory location 2053H.
``` asm
LDA 2050H
MOV E, A
LDA 2051H
MOV B, A
MVI C, 00H
MOV A, B
ORA A
JZ DIVZERO
MOV A, E
LOOP: CMP B
JC DONE
SUB B
INR C
JMP LOOP
DONE: STA 2053H
MOV A, C
STA 2052H
HLT
DIVZERO: MVI A, 0FFH
STA 2052H
MOV A, E
STA 2053H
HLT
```
---
### 03. Write an 8085 assembly language program to add two 16-bit numbers stored in memory pairs (2050H-2051H and 2052H-2053H) using the 16-bit addition instruction (DAD D). Store the 16-bit sum at 2054H-2055H and any generated carry bit at 2056H.
``` asm
LHLD 2050H
XCHG
LHLD 2052H
DAD D
SHLD 2054H
MVI A, 00H
ADC A
STA 2056H
HLT
```
---
### 04. Write an 8085 assembly language program to find both the largest and smallest numbers from an array of N 8-bit numbers. Assume the array length N is stored at memory location 2040H and elements begin at 2041H. Store the maximum value at 2060H and the minimum value at 2061H.
``` asm
LDA 2040H
MOV C, A
LXI H, 2041H
MOV A, M
MOV B, A
MOV D, A
DCR C
JZ STORE
LOOP: INX H
MOV A, M
CMP B
JC CHECKMIN
MOV B, A
CHECKMIN: CMP D
JNC NEXT
MOV D, A
NEXT: DCR C
JNZ LOOP
STORE: MOV A, B
STA 2060H
MOV A, D
STA 2061H
HLT
```
---
### 05. Write an 8085 assembly language program to search for a target 8-bit key in an array of N elements. The length N is stored at 2040H, target key at 2041H, and array elements start from 2042H. If the key is present, store its memory address or 1-based index at 2070H; if not found, store 00H (or FFH) at 2070H.
``` asm 
LDA 2040H
MOV B, A
LDA 2041H
MOV D, A
LXI H, 2042H
MVI C, 01H
LOOP: MOV A,B
ORA A
JZ NOTFOUND
MOV A, M
CMP D
JZ FOUND
INX H
INR C
DCR B
JMP LOOP
FOUND: MOV A, C
STA 2070H
HLT
NOTFOUND: MVI A, 00H
STA 2070H
HLT
```
---
### 06. Write an 8085 assembly language program to inspect an array of N 8-bit integers starting at memory location 2041H (with count N at 2040H) and determine the frequency of even and odd values. Store the count of even numbers at 2050H and odd numbers at 2051H.
``` asm
LDA 2040H
MOV B, A
LXI H, 2041H
MVI C, 00H
MVI D, 00H
LOOP: MOV A, B
ORA A
JZ STORE
MOV A, M
ANI 01H
JNZ ODD
INR C
JMP NEXT
ODD: INR D
NEXT: INX H
DCR B
JMP LOOP
STORE: MOV A, C
STA 2050H
MOV A, D
STA 2051H
HLT
```
---
# Arduino
### 01. Design and simulate an LED blinking system using an Arduino UNO. Write and implement Arduino programs to blink an LED for different time intervals using the `delay()` function and without using the `delay()` function. Develop the programs using Arduino IDE and simulate the circuit in Proteus.
- With `delay()`
``` c
int ledPin = 8;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  digitalWrite(ledPin, HIGH);
  delay(500);
  digitalWrite(ledPin, LOW);
  delay(1000);
}
```
- Without `delay()`
``` c 
int ledPin = 8;
unsigned long previousMillis = 0;
unsigned long onTime = 500;
unsigned long offTime = 1000;
bool ledState = HIGH;

void setup() {
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, ledState);
  previousMillis = millis();
}

void loop() {
  unsigned long currentMillis = millis();
  unsigned long interval = ledState ? onTime : offTime;

  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    ledState = !ledState;
    digitalWrite(ledPin, ledState);
  }
}
```
### Diagram: [BlinkLedArduino](Proteus/BlinkLedArduino.pdsprj)
![Arduino Blink LED](Diagrams/BlinkLEDArduino.png)
---
### 02. Design and simulate an interface between an Arduino UNO and a seven-segment display. Write an Arduino program to display decimal numbers from 0 to 9 on the seven-segment display. Develop and compile the program using Arduino IDE and simulate the complete circuit in Proteus.
``` c
int segmentPins[7] = {2, 3, 4, 5, 6, 7, 8};

int digits[10][7] = {
  {1,1,1,1,1,1,0},
  {0,1,1,0,0,0,0},
  {1,1,0,1,1,0,1},
  {1,1,1,1,0,0,1},
  {0,1,1,0,0,1,1},
  {1,0,1,1,0,1,1},
  {1,0,1,1,1,1,1},
  {1,1,1,0,0,0,0},
  {1,1,1,1,1,1,1},
  {1,1,1,1,0,1,1}
};

void setup() {
    for (int i = 0; i < 7; i++) {
      pinMode(segmentPins[i], OUTPUT);
    }
}

void loop() {
  for (int number = 0; number < 10; number++) {
    for (int i = 0; i < 7; i++) {
      digitalWrite(segmentPins[i], digits[number][i]);
    }
    delay(1000);
  }
}
```
### Diagram: [SevenSegmentDisplay](Proteus/SevenSegmentDisplay.pdsprj)
![](Diagrams/SevenSegmentDisplay.png)
---
### 03. Design and simulate a basic calculator using an Arduino UNO in Proteus. The calculator should accept two numbers through a 4×4 matrix keypad and perform addition, subtraction, multiplication and division operations. Display the entered numbers, operator and calculated result on a 16×2 LCD. Develop and compile the program using Arduino IDE and simulate the complete circuit in Proteus.
``` c
#include <LiquidCrystal.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const byte rowPins[4] = {9, 8, 7, 6};
const byte colPins[4] = {A0, A1, A2, A3};

const char keyMap[4][4] = {
  {'7', '8', '9', 'D'},
  {'4', '5', '6', 'C'},
  {'1', '2', '3', 'B'},
  {'*', '0', '#', 'A'}
};

char input[11] = "";
byte inputLength = 0;

long num1 = 0;
long num2 = 0;
double result = 0;

char operation = '\0';
bool secondNumber = false;
bool finished = false;

char getKey() {
  for (byte r = 0; r < 4; r++) {
    digitalWrite(rowPins[r], LOW);

    for (byte c = 0; c < 4; c++) {
      if (digitalRead(colPins[c]) == LOW) {
        delay(25);

        if (digitalRead(colPins[c]) == LOW) {
          char key = keyMap[r][c];

          while (digitalRead(colPins[c]) == LOW) {
            delay(5);
          }

          digitalWrite(rowPins[r], HIGH);
          return key;
        }
      }
    }
    digitalWrite(rowPins[r], HIGH);
  }
  return '\0';
}

void clearInput() {
  inputLength = 0;
  input[0] = '\0';
}

void resetCalculator() {
  num1 = 0;
  num2 = 0;
  result = 0;
  operation = '\0';
  secondNumber = false;
  finished = false;
  clearInput();

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Enter number:");
}

void showExpression() {
  lcd.clear();
  lcd.setCursor(0, 0);

  if (operation == '\0') {
    lcd.print(input);
  } else {
    lcd.print(num1);
    lcd.print(operation);
    lcd.print(input);
  }
}

void setup() {
  for (byte r = 0; r < 4; r++) {
    pinMode(rowPins[r], OUTPUT);
    digitalWrite(rowPins[r], HIGH);
  }

  for (byte c = 0; c < 4; c++) {
    pinMode(colPins[c], INPUT_PULLUP);
  }

  lcd.begin(16, 2);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("ATmega328P Calc");
  delay(1200);

  resetCalculator();
}

void loop() {
  char key = getKey();

  if (key == '\0') {
    return;
  }

  if (key == '*') {
    resetCalculator();
    return;
  }

  if (key >= '0' && key <= '9') {
    if (finished) {
      resetCalculator();
    }

    if (inputLength < 10) {
      input[inputLength++] = key;
      input[inputLength] = '\0';
      showExpression();
    }
    return;
  }

  if (key == 'A' || key == 'B' || key == 'C' || key == 'D') {

    if (inputLength == 0 || operation != '\0' || finished) {
      return;
    }

    num1 = atol(input);
    operation = (key == 'A') ? '+' : (key == 'B') ? '-' : (key == 'C') ? '*' : '/';

    secondNumber = true;
    clearInput();

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(num1);
    lcd.print(operation);
    return;
  }

  if (key == '#') {
    if (operation == '\0' || inputLength == 0 || !secondNumber) {
      return;
    }

    num2 = atol(input);

    switch (operation) {
      case '+':
        result = (double)num1 + num2;
        break;
      case '-':
        result = (double)num1 - num2;
        break;
      case '*':
        result = (double)num1 * num2;
        break;
      case '/':
        if (num2 == 0) {
          lcd.clear();
          lcd.print("Cannot divide");
          lcd.setCursor(0, 1);
          lcd.print("by zero!");
          finished = true;
          return;
        }
        result = (double)num1 / num2;
        break;
    }

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(num1);
    lcd.print(operation);
    lcd.print(num2);

    lcd.setCursor(0, 1);
    lcd.print("Ans=");

    if (fabs(result - round(result)) < 0.000001) {
      lcd.print(result, 0);
    } else {
      lcd.print(result, 4);
    }
    finished = true;
  }
}
```
### Diagram: [Calculator](Proteus/Calculator.pdsprj)
![](Diagrams/Calculator.png)
---
### 04. Design a Smart Door Locking System using an Arduino in Arduino IDE and simulate it in Proteus.
``` c
#include <LiquidCrystal.h>
#include <Servo.h>

LiquidCrystal lcd(10, 11, 12, 13, A0, A1);
Servo door;
const byte ROWS = 4;
const byte COLS = 3;

char keys[ROWS][COLS] = {
  {'1', '2', '3'},
  {'4', '5', '6'},
  {'7', '8', '9'},
  {'*', '0', '#'}
};

byte rowPins[ROWS] = {2, 3, 4, 5};
byte colPins[COLS] = {6, 7, 8};
String password = "1234";
String entered = "";

int attempts = 0;
bool lockedOut = false;
unsigned long lockoutStart = 0;

char scanKeypad() {
  for (byte r = 0; r < ROWS; r++) {
    digitalWrite(rowPins[r], LOW);
    for (byte c = 0; c < COLS; c++) {
      if (digitalRead(colPins[c]) == LOW) {
        digitalWrite(rowPins[r], HIGH);
        return keys[r][c];
      }
    }
    digitalWrite(rowPins[r], HIGH);
  }
  return '\0';
}

char readKeypad() {
  char key = scanKeypad();
  if (key != '\0') {
    delay(30);
    if (scanKeypad() == key) {
      while (scanKeypad() != '\0') {
        delay(10);
      }
      return key;
    }
  }
  return '\0';
}

void setup() {
  lcd.begin(16, 2);
  door.attach(A2);
  door.write(0);
  pinMode(A3, OUTPUT);
  pinMode(A4, OUTPUT);
  pinMode(A5, OUTPUT);
  digitalWrite(A4, HIGH);
  digitalWrite(A5, LOW);
  for (byte r = 0; r < ROWS; r++) {
    pinMode(rowPins[r], OUTPUT);
    digitalWrite(rowPins[r], HIGH);
  }
  for (byte c = 0; c < COLS; c++) {
    pinMode(colPins[c], INPUT_PULLUP);
  }
  lcd.print("SMART DOOR LOCK");
  lcd.setCursor(0, 1);
  lcd.print("Enter Password");
  delay(1500);
  showPassword();
}

void loop() {
  if (lockedOut) {
    if (millis() - lockoutStart >= 10000) {
      lockedOut = false;
      attempts = 0;
      showPassword();
    }
    return;
  }
  char key = readKeypad();
  if (key != '\0') {
    if (key == '*') {
      entered = "";
      showPassword();
    } else if (key == '#') {
      checkPassword();
    } else if (key >= '0' && key <= '9' && entered.length() < 4) {
      entered += key;
      lcd.setCursor(10 + entered.length() - 1, 0);
      lcd.print('*');
    }
  }
}

void showPassword() {
  lcd.clear();
  lcd.print("Password: ");
}

void checkPassword() {
  if (entered == password) {
    attempts = 0;
    lcd.clear();
    lcd.print("ACCESS GRANTED");
    digitalWrite(A4, LOW);
    digitalWrite(A5, HIGH);
    door.write(90);
    delay(5000);
    door.write(0);

    digitalWrite(A4, HIGH);
    digitalWrite(A5, LOW);
    lcd.clear();
    lcd.print("DOOR LOCKED");
    delay(1000);
  } else {
    attempts++;
    lcd.clear();
    lcd.print("ACCESS DENIED");
    tone(A3, 1000, 500);
    delay(1000);
    if (attempts >= 3) {
      lockedOut = true;
      lockoutStart = millis();
      lcd.clear();
      lcd.print("SYSTEM LOCKED");
      lcd.setCursor(0, 1);
      lcd.print("Wait 10 seconds");
    } else {
      lcd.clear();
      lcd.print("Wrong Password");
      lcd.setCursor(0, 1);
      lcd.print("Attempts: ");
      lcd.print(attempts);
      delay(1000);
    }
  }
  entered = "";
  if (!lockedOut) {
    showPassword();
  }
}
```
### Diagram: [SmartLockArduino](Proteus/SmartLockArduino.pdsprj)
![](Diagrams/SmartLockArduino.png)
---
### 05. Blink LED light by Pressing Button
``` c
const int button = 2;
const int led = 13;

void setup() {
  pinMode(button, INPUT_PULLUP);
  pinMode(led, OUTPUT);  
}

void loop() {
  int state = digitalRead(button);
  if (state==LOW) {
    digitalWrite(led, HIGH);
    delay(250);
    digitalWrite(led, LOW);
    delay(250);
  } else {
    digitalWrite(led, LOW);
  }
}
```
### Diagram: [ButtonPush](Proteus/ButtonPush.pdsprj)
![](Diagrams/ButtonPush.png)
---
### 06. Write Messages (Hello World) on LCD Display.
``` c
#include <LiquidCrystal.h>

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);
 
void setup(){
   lcd.begin(16, 2);
   lcd.setCursor(0, 0);
   lcd.print("Hello World!");
}

void loop(){

}
``` 
### Diagram: [WriteMessage](Proteus/WriteMessage.pdsprj)
![](Diagrams/WriteMessage.png)
---
### 07. Design a Traffic Light Using Arduino UNO.
``` c
const int red = 2, yellow = 3, green = 4;
 
void setup(){
   pinMode(red, OUTPUT);
   pinMode(yellow, OUTPUT);
   pinMode(green, OUTPUT);
}

void loop(){
   digitalWrite(red, HIGH);
   delay(1000);
   digitalWrite(yellow, HIGH);
   digitalWrite(red, LOW);
   delay(750);
   digitalWrite(green, HIGH);
   digitalWrite(yellow, LOW);
   delay(500);
   digitalWrite(green, LOW);
}
```
### Diagram: [TrafficLightArduino](Proteus/TrafficLightArduino.pdsprj)
![](Diagrams/TrafficLightArduino.png)
---
### 08. Design a Counter upto 100 using Arduino.
``` c
#include <LiquidCrystal.h>

LiquidCrystal lcd( 14, 13, 5, 4, 3, 2);

int counter = 0;
 
void setup(){
   lcd.begin(16, 2);
   lcd.setCursor(0, 0);
   lcd.print("Digital Counter");
}

void loop(){
   lcd.setCursor(0, 1);
   lcd.print("Counter:   ");
   lcd.setCursor(9, 1);
   lcd.print(counter);
   counter++;
   if(counter==100) {
      counter = 0;
   }
   delay(100);
}
```
### Diagram: [Counter100](Proteus/Counter100.pdsprj)
![](Diagrams/Counter100.png)
---
### 09. LED Pattern using Arduino.
``` c
const int pins[5] = { 2, 3, 4, 5, 6};
const int numLight = 5;
 
void setup(){
   for(int i=0;i<numLight;i++) {
      pinMode(pins[i], OUTPUT);
   }
}

void loop(){
   for(int i=0;i<numLight;i++){
      digitalWrite(pins[i], HIGH);
      delay(500);
      digitalWrite(pins[i], LOW);
   }
   for(int i=numLight-1;i>=0;i--) {
      digitalWrite(pins[i], HIGH);
      delay(500);
      digitalWrite(pins[i], LOW);
   }
}
```
### Diagram: [LEDDance](Proteus/LEDDance.pdsprj)
![](Diagrams/LEDDance.png)
---
### 10. IR Sensor using Arduino.
``` c
const int irPin = 2;
const int ledPin = 13;
 
void setup(){
   pinMode(irPin, INPUT);
   pinMode(ledPin, OUTPUT);
   Serial.begin(9600);
}

void loop(){
   int state = digitalRead(irPin);
   
   if (state==HIGH) {
      digitalWrite(ledPin, HIGH);
      Serial.println("Object Detected!");
   } else {
      digitalWrite(ledPin, LOW);
      Serial.println("No Object Detected");
   } delay(100);
}
```
### Diagram: [IRSensor](Proteus/IRSensor.pdsprj)
![](Diagrams/IRSensor.png)
---
### 11. Print Current Tempreture using Arduino and LM35 Sensor.
``` c
#include <LiquidCrystal.h>

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int tempPin = A0;
 
void setup(){
   lcd.begin(16, 2);
   lcd.setCursor(0, 0);
   lcd.print("Current Tempreture: ");
   Serial.begin(9600);
}

void loop(){
   int value = analogRead(tempPin);
   float voltage = value * (5.0 / 1023.0);
   float temp = voltage * 100;
   lcd.setCursor(0, 1);
   lcd.print(temp);
   lcd.print(" C");
   delay(100);
}
```
### Diagram: [TempretureSensor](Proteus/TempretureSensor.pdsprj)
![](Diagrams/TempretureSensor.png)
---
### 12. Buzzer Sounds after Temprreture Hits Certain Threshold Value.
``` c
#include <LiquidCrystal.h>

const int buzzerPin = 8;
const float threshold = 40.0;
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int tempPin = A0;
 
void setup(){
   lcd.begin(16, 2);
   lcd.setCursor(0, 0);
   lcd.print("Current Tempreture: ");
   Serial.begin(9600);
}

void loop(){
   int value = analogRead(tempPin);
   float voltage = value * (5.0 / 1023.0);
   float temp = voltage * 100;
   lcd.setCursor(0, 1);
   lcd.print(temp);
   lcd.print(" C");
   
   if(temp>threshold) {
      digitalWrite(buzzerPin, HIGH);
   } else {
      digitalWrite(buzzerPin, LOW);
   }
   
   delay(100);
}
```
### Diagram: [TempretureSensorBuzzer](Proteus/TempretureSensorBuzzer.pdsprj)
![](Diagrams/TempretureSensorBuzzer.png)
---
### 13. Light Sensor Using Arduino.
``` c
#include <LiquidCrystal.h>

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int lightPin = A0;

void setup() {
  lcd.begin(16, 2);
  lcd.setCursor(0, 0);
  lcd.print("Light Value:");
  Serial.begin(9600);
}

void loop() {
  int lightValue = analogRead(lightPin);

  lcd.setCursor(0, 1);
  lcd.print("Value: ");
  lcd.print(lightValue);
  lcd.print("    ");

  Serial.println(lightValue);

  delay(100);
}
```
### Diagram: [LightSensor](Proteus/LightSensor.pdsprj)
![](Diagrams/LightSensor.png)
---